%  Copyright (c) 2014, Karen Simonyan
%  All rights reserved.
%  This code is made available under the terms of the BSD license (see COPYING file).

% VLFeat
run('../../toolboxes/vlfeat/toolbox/vl_setup');

addpath('./common/');
addpath('./gmm-fisher/matlab/');
